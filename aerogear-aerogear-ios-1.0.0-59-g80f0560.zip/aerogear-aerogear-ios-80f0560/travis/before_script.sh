#!/bin/sh
set -e

brew update
brew install xctool
